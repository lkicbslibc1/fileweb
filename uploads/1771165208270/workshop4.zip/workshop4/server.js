const WebSocket = require("ws");
const fs = require("fs");
const os = require("os");

const host = "127.0.0.1"; // หรือใส่ IP เครื่องอาจารย์ถ้าจะเทสต์ข้ามเครื่อง
const portNumber = 8080;
const hostname = os.hostname();

// ฟังก์ชันบันทึก Log (เหมือนเดิม)
function saveLog(type, message) {
  const now = new Date();
  const timeString = now.toLocaleString("th-TH");
  const logEntry = `[${timeString}] [${type}]: ${message}\n`;
  fs.appendFile("server_log.txt", logEntry, (err) => {
    if (err) console.error("Error writing log:", err);
  });
}

const wss = new WebSocket.Server({ port: portNumber }, () => {
  console.log(`Server (${hostname}) running at ws://${host}:${portNumber}`);
  saveLog("SYSTEM", "Server Started");
});

wss.on("connection", (ws) => {
  console.log("New Client Connected.");
  saveLog("CONNECTION", "Client Connected");

  ws.on("message", (message) => {
    const msgStr = message.toString();
    console.log(`Received: ${msgStr}`);
    saveLog("RECEIVED", msgStr);

    // --- จุดที่แก้: Broadcast (ส่งหาทุกคน ยกเว้นตัวเอง) ---
    wss.clients.forEach((client) => {
      // เช็คว่า Client นั้นเปิดอยู่ และไม่ใช่คนที่ส่งมา (client !== ws)
      if (client.readyState === WebSocket.OPEN && client !== ws) {
        client.send(msgStr); // ส่งข้อความไปให้คนอื่น
      }
    });

    // บันทึกว่าส่งออกไปแล้ว
    saveLog("BROADCAST", msgStr);
  });

  ws.on("close", () => {
    console.log("Client Disconnected.");
    saveLog("CONNECTION", "Client Disconnected");
  });
});
