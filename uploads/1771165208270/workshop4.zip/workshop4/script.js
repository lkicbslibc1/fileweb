const ws = new WebSocket("ws://localhost:8080");

const messageInput = document.getElementById("message");
const sendBtn = document.getElementById("sendBtn");
const responseDiv = document.getElementById("response");

// --- 1. โหลดประวัติเก่าตอนเปิดหน้าเว็บ ---
window.onload = () => {
  // ดึงข้อมูลจาก localStorage (ถ้าไม่มีให้เป็น array ว่าง)
  const history = JSON.parse(localStorage.getItem("chatLogs")) || [];

  // วนลูปเอามาแสดงที่หน้าจอ
  history.forEach((log) => {
    renderLogToScreen(log.message, log.color);
  });
};

// --- ฟังก์ชันแสดงผล (แยกออกมาเพื่อใช้ซ้ำ) ---
function renderLogToScreen(fullMessage, color) {
  const p = document.createElement("p");
  p.style.color = color;
  p.style.margin = "5px 0";
  p.textContent = fullMessage;

  responseDiv.appendChild(p);
  responseDiv.scrollTop = responseDiv.scrollHeight;
}

// --- ฟังก์ชันหลัก: สร้างข้อความ + บันทึก + แสดงผล ---
function addLog(text, color = "black") {
  const time = new Date().toLocaleTimeString();
  const fullMessage = `[${time}] ${text}`;

  // 1. แสดงผลเลย
  renderLogToScreen(fullMessage, color);

  // 2. ยัดลง localStorage
  const history = JSON.parse(localStorage.getItem("chatLogs")) || [];
  history.push({ message: fullMessage, color: color });
  localStorage.setItem("chatLogs", JSON.stringify(history));
}

// --- Event Listeners เหมือนเดิม ---

ws.onopen = () => {
  addLog("System: Connected to Server...", "green");
};

ws.onmessage = (event) => {
  addLog(`Server: ${event.data}`, "blue");
};

ws.onclose = () => {
  addLog("System: Disconnected.", "red");
};

sendBtn.addEventListener("click", () => {
  const msg = messageInput.value;

  if (ws.readyState === WebSocket.OPEN) {
    if (msg.trim() !== "") {
      ws.send(msg);
      addLog(`You: ${msg}`, "black");
      messageInput.value = "";
    }
  } else {
    addLog("Error: Connection is closed.", "red");
  }
});

// กด Enter เพื่อส่ง
messageInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    sendBtn.click();
    e.preventDefault();
  }
});
